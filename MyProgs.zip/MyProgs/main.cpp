//
//  main.cpp
//  MyProgs
//
//  Created by Narendra A on 03/10/15.
//  Copyright © 2015 Narendra A. All rights reserved.
//
///usr/local/Cellar/boost/1.58.0/lib/
///usr/local/Cellar/boost/1.58.0/include/
#include "TreeProgram.hpp"
#include "TreeTopos.hpp"
#include "nstairs.hpp"

int main(int argc, char* argv[])
{
    //BSTree::Tree::Driver();
    //NStairs::Driver();
    TreeTopo::Driver();
    return 0;
}