//
//  TreeTopos.hpp
//  MyProgs
//
//  Created by Narendra A on 10/10/15.
//  Copyright © 2015 Narendra A. All rights reserved.
//

#ifndef TreeTopos_hpp
#define TreeTopos_hpp

#include <vector>
#include <iostream>
#include <unordered_map>
#include <bitset>
#include <chrono>
#include <exception>
#include <memory>
#include <boost/multiprecision/cpp_int.hpp>
#include <vector>
#include <set>
#include "TreeProgram.hpp"

using namespace std;
using namespace boost;
using namespace boost::multiprecision;
using namespace boost::multiprecision::backends;
using namespace BSTree;

typedef number<cpp_int_backend<64, 1048576, signed_magnitude, unchecked, void> >   BigInt;
#define node_count 32000

class TreeTopo{
private:
    vector<BigInt> factTable;
public:
    
    TreeTopo(){
        
        uint64_t  i{1};
        BigInt j{1};
        
        this->factTable.reserve(node_count);
        this->factTable[0].assign(1);

        while (i <= node_count){
            this->factTable[i] = this->factTable[i - 1] * j++;
            i++;
        }
    }
    
    BigInt interLeavings(uint64_t a, uint64_t b) {
        return factTable[a + b] / (factTable[a] * factTable[b]);
    }
    
    BigInt countWays(const std::shared_ptr<Node> &p){
        
        if (p == nullptr || p->nodeCount == 1) return 1;
        uint64_t l =  p->left ? p->left->nodeCount : 0 ;
        uint64_t r =  p->right ? p->right->nodeCount : 0 ;
        
        return countWays(p->left) * countWays(p->right) * interLeavings(l, r);
    }

    static void Driver(){
        
        chrono::high_resolution_clock::time_point start1 = chrono::high_resolution_clock::now();
        std::shared_ptr<TreeTopo> tt = std::make_shared<TreeTopo>();
        chrono::high_resolution_clock::time_point end1 = chrono::high_resolution_clock::now();
        
        BigInt t1 = chrono::duration_cast<chrono::microseconds>(end1 - start1).count();
        cout << "Time taken for lookup filling : " << t1 / 1000 << "."
        << t1 % 1000 << " millisec." << endl;
        
        //randomly genrated list of numbers below node_count
        auto bst = std::unique_ptr<BSTree::Tree>();
        int x;
        std::srand(node_count);
        uint64_t preCount, afterCount;
        for (uint64_t i = 0; i < node_count;){
            x = std::rand();
            x %= node_count;
            preCount = bst->count;
            bst->insertNode(x);
            afterCount = bst->count;
            if(afterCount > preCount)
                i++;

        }
        
        BigInt res;
        auto run = [&](int run_num){
            // n()  is the method which does the stuff
            chrono::high_resolution_clock::time_point start = chrono::high_resolution_clock::now();
            res = tt->countWays(bst->getRoot());
            //res = n(a);
            //cout << res << endl;
            chrono::high_resolution_clock::time_point end = chrono::high_resolution_clock::now();
            BigInt t = chrono::duration_cast<chrono::microseconds>(end - start).count();
            cout << "Time taken : in run " << run_num << " " << t / 1000 << "." << t % 1000 << " millisec." << endl;
            
        };
        run(1);
        run(2);
        run(3);
        cout << "Result = " << res << endl;
        unsigned count = 0;
        while (res != 0){
            res /= 10;
            count++;
        }
        
        cout << " number of digits = " << count << endl;
        
    }
};
#endif /* TreeTopos_hpp */
